/*
 * The RoSeal Extension
 * © Copyright 2022-2025 roseal.live, All rights reserved
*/
document.documentElement.setAttribute("data-roseal-data",JSON.stringify({extensionId:globalThis.browser.runtime.id,version:"2.1.0-beta.6",target:"firefox"}));
